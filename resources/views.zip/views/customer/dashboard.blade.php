@extends('customer.layouts.customerMaster')
@section('content')
<div class="row">
    @if ($customer->customer_name)
    <div class="col-lg-4 col-12">
        <div class="small-box bg-info">
            <div class="inner text-center">
                <h3>{{$customer->customer_name}}</h3>
                <p>Name</p>
            </div>
        </div>
    </div>
    @endif
    @if ($customer->employee)
    <div class="col-lg-4 col-12">
        <div class="small-box bg-info">
            <div class="inner text-center">
                <h3>{{$customer->employee->name }} ({{$customer->employee->id }})</h3>
                <p>Employee</p>
            </div>
        </div>
    </div>
    @endif
    @if ($customer->employee)
    <div class="col-lg-4 col-12">
        <div class="small-box bg-info">
            <div class="inner text-center">
                <h3>{{$customer->employee->company->name}}</h3>
                <p>Company</p>
            </div>
        </div>
    </div>
    @endif

</div>
@endsection
