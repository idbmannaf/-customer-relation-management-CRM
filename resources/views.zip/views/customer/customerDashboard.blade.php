@extends('customer.layouts.customerMaster')
@section('content')
Customer
@endsection
