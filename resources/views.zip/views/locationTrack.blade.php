@auth
@if (auth()->user()->track)
    <script type="text/javascript">
        window.onload = function() {
            getLocation()
        }

        var geo = navigator
            .geolocation; /*     Here we will check if the browser supports the Geolocation API; if exists, then we will display the location     */

        function getLocation() {
            if (geo) {
                geo.watchPosition(displayLocation);

            } else {

                // alert( "Oops, Geolocation API is not supported");
            }
        }

        /*     This function displays the latitude and longitude when the browser has a location.     */

        function displayLocation(position) {
            document.getElementById('lati').value = position.coords.latitude;
            document.getElementById('long').value = position.coords.longitude;
        }
    </script>

    <script>
        $(document).ready(function() {
            setInterval(function() {
                var lat = getCookieData('lat')
                var long = getCookieData('long')

                if (lat != false && long != false) {
                    ajaxRequest(lat, long);
                } else {
                    var lat = $("#lati").val();
                    var lng = $("#long").val();
                    var dist = 0;
                    var url = $(".user-location-set").attr('data-url');
                    var urls = url + '?lat=' + lat + '&lng=' + lng;
                    $.ajax({
                        url: urls,
                        type: "get",
                        success: function(response) {
                            if (response.success) {
                                $("#lati").val(response.lat);
                                $("#long").val(response.lng);
                            }
                        }
                    });
                }

            }, 6000);


            function getCookieData(name) {
                var patrn = new RegExp("^" + name + "=(.*?);"),
                    patr2 = new RegExp(" " + name + "=(.*?);");
                if (match = (document.cookie.match(patrn) || document.cookie.match(patr2))) {
                    return match[1];
                } else {
                    return false;
                }
            }

            function ajaxRequest(lat, long) {
                var url = $(".user-location-set").attr('data-url');
                var urls = url + '?lat=' + lat + '&lng=' + long;
                $.ajax({
                    url: urls,
                    method: "GET",
                    success: function(res) {
                        // if (res.success) {
                        //     alert('Success');
                        // } else {
                        //     alert('Error');
                        // }
                    }
                })
            }


        });
    </script>

@endif
@endauth
