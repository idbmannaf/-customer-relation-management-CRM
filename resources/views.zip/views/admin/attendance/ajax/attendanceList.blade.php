<div class="table-responsive">
    <table class="table table-bordered table-sm">
        <thead>
            <th>Sl</th>
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Entry Time</th>
            <th>Exit Time</th>
            <th>Duration</th>
            <th>Status</th>
            <th>Company</th>
            <th>Office Location</th>
        </thead>
        <tbody>
            <?php $i = 1;
            $i = ($attendances->currentPage() - 1) * $attendances->perPage() + 1;
            ?>
            @foreach ($attendances as $attendance)
                <tr>
                    <td>{{ $i }}</td>
                    <td>{{ $attendance->user->username }}</td>
                    <td>{{ $attendance->user->name }}</td>
                    <td>{{ $attendance->logged_in_at }}</td>
                    <td>{{ $attendance->logged_out_at }}</td>
                    <td>{{ timestamToTimeDiffarece($attendance->logged_in_at, $attendance->logged_out_at) }}</td>
                    <td>
                        {{-- {{$attendance->user->officeLocation->office_start_time}} --}}
                        @if ($attendance->user->officeLocation->office_start_time < \Carbon\Carbon::parse($attendance->logged_in_at)->format('H:m:s'))
                            <span class="text-danger">Late Entry</span>
                            @else
                            <span class="text-success">Present</span>
                        @endif
                    </td>

                    <td>{{ $attendance->user->officeLocation->company->name }}</td>
                    <td>{{ $attendance->user->officeLocation->title }}</td>
                </tr>
                <?php $i++; ?>
            @endforeach
        </tbody>
    </table>
</div>
{{$attendances->render(0)}}
