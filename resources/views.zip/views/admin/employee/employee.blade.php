@extends('admin.layouts.adminMaster')
@push('title')
    | Admin Dashboard | Employees
@endpush


@section('content')
    <div class="card shadow">
        <div class="card-header bg-info">
            <div class="card-title">Employees
                @can('employee-add')
                <a href="{{ route('admin.employee.create') }}" class="btn btn-danger"><i class="fas fa-plus"></i></a>
                @endcan
            </div>
        </div>
        @include('alerts.alerts')

        <div class="card-body">

            @can('employee-bulk-upload')
            <div class="row pb-2">
                <div class="col-12 col-md-3">
                    <fieldset>
                        <legend>Bulk Upload <a href="{{ asset('img/employeeDemo.png') }}" class="badge badge-danger"
                                data-lightbox="roadtrip" title="Follow The instruction "><i class="fas fa-info"></i></a>
                        </legend>
                        <form action="{{ route('admin.employee.store', ['type' => 'bulk']) }}"
                            enctype="multipart/form-data" method="post">
                            @csrf
                            <div class="form-group">
                                <input type="file" name="file">
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Upload" class="btn btn-info">
                            </div>
                        </form>
                    </fieldset>
                </div>
            </div>
            @endcan

            @can('employee-search')
            <div class="d-flex justify-content-end pb-2">
                <div class="">
                    <div class="d-flex justify-content-end">
                        <input type="text" name="q" id="search" class="form-control"
                            placeholder="Search via Emplyee Id or Name" data-url="{{ route('admin.employee.search') }}">
                    </div>
                </div>
            </div>
            @endcan


            <div class="showEmployee">
                @include('admin.employee.ajax.employeeList')
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script>
        $(document).on('click', '.pagination a', function(e) {
            e.preventDefault();
            var url = $(this).attr('href');
            $.ajax({
                url: url,
                method: "GET",
                success: function(res) {
                    $('.showEmployee').html(res);
                }
            })
        })

        $(document).on('input', '#search', function(e) {
            var q = $(this).val();
            var url = $(this).attr('data-url');
            var finalUrl = url + "?q=" + q;
            $.ajax({
                url: finalUrl,
                method: "GET",
                success: function(res) {
                    $('.showEmployee').html(res);
                }
            })
        })
    </script>
@endpush
