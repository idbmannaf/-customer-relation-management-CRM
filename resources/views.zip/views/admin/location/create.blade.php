@extends('admin.layouts.adminMaster')
@push('title')
    | Admin Dashboard | Office Location Create
@endpush


@section('content')
    <div class="card shadow">
        <div class="card-header bg-info">
            <div class="card-title">Office Locations Create
            </div>
        </div>
        <div class="card-body">
            @include('alerts.alerts')
            <form action="{{ route('admin.gStore') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <div class="col-md-12 my-2">
                                <label for="location-input">Location Name</label>
                                <input type="text" name="name"
                                    class="form-control pac-target-input @error('location') is-invalid @enderror"
                                    id="location-input" placeholder="Google Location" autocomplete="off">
                            </div>
                            <div class="col-md-12 my-2">
                                <label for="location-input">Google Location</label>
                                <input type="text" name="location"
                                    class="form-control pac-target-input @error('location') is-invalid @enderror"
                                    id="location-input" placeholder="Google Location" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="lat">Latitude</label>
                            <input type="text" name="lat" id="lat1" class="form-control @error('lat') is-invalid @enderror "
                                placeholder="Latitude Here">
                        </div>
                        <div class="form-group">
                            <label for="lng">Longitude</label>
                            <input type="text" name="lng" id="lng1" class="form-control @error('lng') is-invalid @enderror "
                                placeholder="Longitude Here">
                        </div>

                    </div>
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <label for="division">Division</label>
                            <select name="division" id="division"
                                class="form-control custom-select div-select @error('division') is-invalid @enderror ">
                                <option value="">Select Division</option>
                                @foreach ($divisions as $division)
                                    <option value="{{ $division->id }}">{{ $division->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="district">District</label>
                            <select name="district" id="district"
                                class="form-control custom-select dist-select @error('district') is-invalid @enderror ">
                                <option value="">Select District</option>

                            </select>
                        </div>
                        <div class="form-group">
                            <label for="thana">Thana</label>
                            <select name="thana" id="thana"
                                class="form-control custom-select thana-select @error('thana') is-invalid @enderror ">
                                <option value="">Select Thana</option>

                            </select>
                        </div>
                        <div class="form-group ">
                            <label for="feature_image" class="col-sm-5 form-control-label"></label>
                            <div class="col-sm-8">
                                <input type="submit" class="form-control btn btn-info">
                            </div>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
@endsection

@push('js')
    <script type="text/javascript">
        window.onload = function() {
            var lat = getCookieData('lat')
            var long = getCookieData('long')
            if (lat != false && long != false) {
                $('#lat1').val(lat);
                $('#lng1').val(long);
            } else {

                getLocation()
            }
        }

        var geo = navigator
            .geolocation; /*     Here we will check if the browser supports the Geolocation API; if exists, then we will display the location     */

        function getLocation() {
            if (geo) {
                geo.watchPosition(displayLocation);

            } else {
                // alert( "Oops, Geolocation API is not supported");
            }
        }

        /*     This function displays the latitude and longitude when the browser has a location.     */

        function displayLocation(position) {
            document.getElementById('lat1').value = position.coords.latitude;
            document.getElementById('lng1').value = position.coords.longitude;
        }

        function getCookieData(name) {
                var patrn = new RegExp("^" + name + "=(.*?);"),
                    patr2 = new RegExp(" " + name + "=(.*?);");
                if (match = (document.cookie.match(patrn) || document.cookie.match(patr2))) {
                    return match[1];
                } else {
                    return false;
                }
            }

            function ajaxRequest(lat, long) {
                var url = $(".user-location-set").attr('data-url');
                var urls = url + '?lat=' + lat + '&lng=' + long;
                $.ajax({
                    url: urls,
                    method: "GET",
                    success: function(res) {
                        // if (res.success) {
                        //     alert('Success');
                        // } else {
                        //     alert('Error');
                        // }
                    }
                })
            }
    </script>
    <script>
        // $(document).ready(function() {

        //     function getCookieData(name) {
        //         var patrn = new RegExp("^" + name + "=(.*?);"),
        //             patr2 = new RegExp(" " + name + "=(.*?);");
        //         if (match = (document.cookie.match(patrn) || document.cookie.match(patr2))) {
        //             return match[1];
        //         } else {
        //             return false;
        //         }
        //     }

        //     function ajaxRequest(lat, long) {
        //         var url = $(".user-location-set").attr('data-url');
        //         var urls = url + '?lat=' + lat + '&lng=' + long;
        //         $.ajax({
        //             url: urls,
        //             method: "GET",
        //             success: function(res) {
        //                 // if (res.success) {
        //                 //     alert('Success');
        //                 // } else {
        //                 //     alert('Error');
        //                 // }
        //             }
        //         })
        //     }


        // });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            var dists = <?php echo json_encode($districts); ?>;
            var thanas = <?php echo json_encode($thanas); ?>

            $(document).on("change", ".div-select", function(e) {
                // e.preventDefault();

                var that = $(this);
                var q = that.val();

                that.closest('form').find(".thana-select").empty().append($('<option>', {
                    value: '',
                    text: 'Thana'
                }));

                that.closest('form').find(".dist-select").empty().append($('<option>', {
                    value: '',
                    text: 'District'
                }));

                $.each(dists, function(i, item) {
                    if (item.division_id == q) {
                        that.closest('form').find(".dist-select").append(
                            "<option value='" + item.id + "'>" + item.name +
                            "</option>");
                    }
                });

                $.each(thanas, function(i, item) {
                    if (item.division_id == q) {
                        that.closest('form').find(".thana-select").append(
                            "<option value='" + item.id + "'>" + item.name +
                            "</option>");
                    }
                });

            });


            $(document).on("change", ".dist-select", function(e) {
                // e.preventDefault();

                var that = $(this);
                var q = that.val();

                that.closest('form').find(".thana-select").empty().append($('<option>', {
                    value: '',
                    text: 'Thana'
                }));

                $.each(thanas, function(i, item) {
                    if (item.district_id == q) {
                        that.closest('form').find(".thana-select").append(
                            "<option value='" + item.id + "'>" + item.name +
                            "</option>");
                    }
                });

            });


        });
    </script>
@endpush
