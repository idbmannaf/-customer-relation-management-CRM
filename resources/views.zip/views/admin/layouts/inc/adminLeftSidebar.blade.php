<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/" class="brand-link">
        <img src="{{ asset('img/logo.png') }}" alt="{{ env('APP_NAME') }}" class="brand-image img-circle elevation-3"
            style="opacity: .8">
        <span class="brand-text font-weight-light">{{ env('APP_NAME') }}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2 ">
            <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-legacy" data-widget="treeview" role="menu"
                data-accordion="true">
                <li class="nav-item text-center">
                    <a href="{{ route('admin.glocation') }}" class="btn btn-danger " data-toggle="modal" data-target="#exampleModal" data-whatever="@fat"
                        class="nav-link {{ session('lsbsm') == 'glocation' ? ' active ' : '' }}">
                        <i class="fas fa-map"></i>
                        <p>{{ __('Add Location') }}</p>
                    </a>
                </li>

                <li class="nav-item {{ session('lsbm') == 'dashboard' ? ' menu-open ' : '' }}">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('admin.dashboard') }}"
                                class="nav-link {{ session('lsbsm') == 'profile' ? ' active ' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>{{ __('Dashboard') }}</p>
                            </a>
                        </li>
                    </ul>
                    {{-- <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="{{ route('admin.dashboard') }}"
                                class="nav-link {{ session('lsbsm') == 'dashboard' ? ' active ' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        @can('website-parameters')
                            <li class="nav-item">
                                <a href="{{ route('admin.websiteparam.index') }}"
                                    class="nav-link {{ session('lsbsm') == 'websiteParam' ? ' active ' : '' }}">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Website Parameter</p>
                                </a>
                            </li>
                        @endcan


                    </ul> --}}
                </li>
                @if (auth()->user()->can('role-and-permission'))
                    <li class="nav-item {{ session('lsbm') == 'role' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-user-lock"></i>
                            <p>
                                Role & Permission
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin.roles.index') }}"
                                    class="nav-link {{ session('lsbsm') == 'allRoles' ? ' active ' : '' }}">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>{{ __('All Roles') }}</p>
                                </a>
                            </li>
                            {{-- <li class="nav-item">
            <a href="{{ route('admin.roles.create') }}"
                class="nav-link {{ session('lsbsm') == 'roleCreate' ? ' active ' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>{{ __('Create Roles') }}</p>
            </a>
        </li> --}}

                            <li class="nav-item">
                                <a href="{{ route('admin.permissions.index') }}"
                                    class="nav-link {{ session('lsbsm') == 'allPermission' ? ' active ' : '' }}">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>All Permissions</p>
                                </a>
                            </li>
                            {{-- <li class="nav-item">
            <a href="{{ route('admin.permissions.create') }}"
                class="nav-link {{ session('lsbsm') == 'newPermission' ? ' active ' : '' }}">
                <i class="far fa-circle nav-icon"></i>
                <p>New Permission</p>
            </a>
        </li> --}}
                            <li class="nav-item">
                                <a href="{{ route('admin.assignRole') }}"
                                    class="nav-link {{ session('lsbsm') == 'assignRole' ? ' active ' : '' }}">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Assign Role</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endif


                {{-- Users --}}
                @if (auth()->user()->can('user-list') ||
    auth()->user()->can('user-add') ||
    auth()->user()->can('user-edit') ||
    auth()->user()->can('user-delete') ||
    auth()->user()->can('user-with-roles'))
                    <li class="nav-item {{ session('lsbm') == 'users' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-users"></i>
                            <p>
                                Users
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('user-list')
                                <li class="nav-item">
                                    <a href="{{ route('admin.user.index') }}"
                                        class="nav-link {{ session('lsbsm') == 'allUsers' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('All Users') }}</p>
                                    </a>
                                </li>
                            @endcan
                            @can('user-add')
                                <li class="nav-item">
                                    <a href="{{ route('admin.user.create') }}"
                                        class="nav-link {{ session('lsbsm') == 'createUser' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('Create User') }}</p>
                                    </a>
                                </li>
                            @endcan
                            @can('user-with-roles')
                                <li class="nav-item">
                                    <a href="{{ route('admin.user.userWithRoles') }}"
                                        class="nav-link {{ session('lsbsm') == 'userWithRoles' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('User With Roles') }}</p>
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endif

                {{-- Company --}}
                @if (auth()->user()->can('company-list') ||
                auth()->user()->can('company-add') ||
                auth()->user('company-edit')->can('company-delete') ||
                auth()->user()->can('company-offices') ||
                auth()->user()->can('company-customers') ||
                auth()->user()->can('company-employees'))
                                <li class="nav-item {{ session('lsbm') == 'companies' ? ' menu-open ' : '' }}">
                                    <a href="#" class="nav-link ">
                                        <i class="nav-icon fas fa-building"></i>
                                        <p>
                                            Companies
                                            <i class="right fas fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        @can('company-list')
                                            <li class="nav-item">
                                                <a href="{{ route('admin.company.index') }}"
                                                    class="nav-link {{ session('lsbsm') == 'allCompanies' ? ' active ' : '' }}">
                                                    <i class="far fa-circle nav-icon"></i>
                                                    <p>{{ __('All Companies') }}</p>
                                                </a>
                                            </li>
                                        @endcan
                                        @can('company-add')
                                            <li class="nav-item">
                                                <a href="{{ route('admin.company.create') }}"
                                                    class="nav-link {{ session('lsbsm') == 'createCompany' ? ' active ' : '' }}">
                                                    <i class="far fa-circle nav-icon"></i>
                                                    <p>{{ __('Create Company') }}</p>
                                                </a>
                                            </li>
                                        @endcan
                                    </ul>
                                </li>
                            @endif

                            {{-- Employee --}}
                            @if (auth()->user()->can('employee-list') ||
                auth()->user()->can('employee-add') ||
                auth()->user()->can('employee-edit') ||
                auth()->user()->can('employee-delete') ||
                auth()->user()->can('employee-location') ||
                auth()->user()->can('employee-attandance') ||
                auth()->user()->can('employee-bulk-upload'))
                                <li class="nav-item {{ session('lsbm') == 'employees' ? ' menu-open ' : '' }}">
                                    <a href="#" class="nav-link ">
                                        <i class="nav-icon fas fa-building"></i>
                                        <p>
                                            Employees
                                            <i class="right fas fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        @can('employee-list')
                                            <li class="nav-item">
                                                <a href="{{ route('admin.employee.index') }}"
                                                    class="nav-link {{ session('lsbsm') == 'allEmployees' ? ' active ' : '' }}">
                                                    <i class="far fa-circle nav-icon"></i>
                                                    <p>{{ __('All Employees') }}</p>
                                                </a>
                                            </li>
                                        @endcan
                                    </ul>
                                </li>
                            @endif

                            {{-- <li class="nav-item {{ session('lsbm') == 'teams' ? ' menu-open ' : '' }}">
                                <a href="#" class="nav-link ">
                                    <i class="nav-icon fas fa-building"></i>
                                    <p>
                                        Teams
                                        <i class="right fas fa-angle-left"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="{{ route('admin.team.index') }}"
                                            class="nav-link {{ session('lsbsm') == 'allTeam' ? ' active ' : '' }}">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>{{ __('All Team') }}</p>
                                        </a>
                                    </li>

                                </ul>
                            </li> --}}
                            @if (auth()->user()->can('customer-list') ||
                auth()->user()->can('customer-add') ||
                auth()->user()->can('customer-edit') ||
                auth()->user()->can('customer-delete') ||
                auth()->user()->can('customer-bulk-upload'))
                    <li class="nav-item {{ session('lsbm') == 'customers' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Customers
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('customer-list')
                                <li class="nav-item">
                                    <a href="{{ route('admin.customer.index') }}"
                                        class="nav-link {{ session('lsbsm') == 'allCustomers' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('All Customers') }}</p>
                                    </a>
                                </li>
                            @endcan

                            @can('customer-add')
                                <li class="nav-item">
                                    <a href="{{ route('admin.customer.create') }}"
                                        class="nav-link {{ session('lsbsm') == 'addCustomers' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('Add Customer') }}</p>
                                    </a>
                                </li>
                            @endcan

                        </ul>
                    </li>
                @endif

                @if (auth()->user()->can('office-location-list') ||
                    auth()->user()->can('office-location-add') ||
                    auth()->user()->can('office-location-edit') ||
                    auth()->user()->can('office-location-delete'))
                    <li class="nav-item {{ session('lsbm') == 'officeLocation' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Office Location
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('office-location-list')
                                <li class="nav-item">
                                    <a href="{{ route('admin.location.index') }}"
                                        class="nav-link {{ session('lsbsm') == 'AllLocations' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('All Locations') }}</p>
                                    </a>
                                </li>
                            @endcan
                            @can('office-location-add')
                                <li class="nav-item">
                                    <a href="{{ route('admin.location.create') }}"
                                        class="nav-link {{ session('lsbsm') == 'createLocations' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('Create Locations') }}</p>
                                    </a>
                                </li>
                            @endcan


                        </ul>
                    </li>
                @endif

                @if (auth()->user()->can('attendance-today') ||
                    auth()->user()->can('attendance-history') ||
                    auth()->user()->can('attendance-report')

                    )
                    <li class="nav-item {{ session('lsbm') == 'attendance' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Attendance
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('attendance-today')
                                <li class="nav-item">
                                    <a href="{{ route('admin.attendance') }}"
                                        class="nav-link {{ session('lsbsm') == 'allAttendance' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('Today') }}</p>
                                    </a>
                                </li>
                            @endcan

                            @can('attendance-history')
                                <li class="nav-item">
                                    <a href="{{ route('admin.attendanceHistory') }}"
                                        class="nav-link {{ session('lsbsm') == 'attendanceHistory' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('History') }}</p>
                                    </a>
                                </li>
                            @endcan
                            @can('attendance-report')
                                <li class="nav-item">
                                    <a href="{{ route('admin.attendanceReport') }}"
                                        class="nav-link {{ session('lsbsm') == 'attendanceReport' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('Report') }}</p>
                                    </a>
                                </li>
                            @endcan


                        </ul>
                    </li>
                @endif
                @if (auth()->user()->can('designation-list') ||
                auth()->user()->can('designation-add') ||
                auth()->user()->can('designation-edit') ||
                auth()->user()->can('designation-delete'))
                    <li class="nav-item {{ session('lsbm') == 'designation' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Designations
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @if (auth()->user()->can('designation-list') ||
            auth()->user()->can('designation-add'))
                                <li class="nav-item">
                                    <a href="{{ route('admin.designation.index') }}"
                                        class="nav-link {{ session('lsbsm') == 'allDesignation' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('All Designations') }}</p>
                                    </a>
                                </li>
                            @endif

                        </ul>
                    </li>
                @endif

                @if (auth()->user()->can('department-list') ||
    auth()->user()->can('department-add') ||
    auth()->user()->can('department-edit') ||
    auth()->user()->can('department-delete'))
                    <li class="nav-item {{ session('lsbm') == 'department' ? ' menu-open ' : '' }}">
                        <a href="#" class="nav-link ">
                            <i class="nav-icon fas fa-building"></i>
                            <p>
                                Departments
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @if (auth()->user()->can('department-list') ||
                            auth()->user()->can('department-add'))
                                <li class="nav-item">
                                    <a href="{{ route('admin.department.index') }}"
                                        class="nav-link {{ session('lsbsm') == 'allDepartment' ? ' active ' : '' }}">
                                        <i class="far fa-circle nav-icon"></i>
                                        <p>{{ __('All Departments') }}</p>
                                    </a>
                                </li>
                            @endif

                        </ul>
                    </li>
                @endif

                <li class="nav-item {{ session('lsbm') == 'glocation' ? ' menu-open ' : '' }}">
                    <a href="#" class="nav-link ">
                        <i class="nav-icon fas fa-building"></i>
                        <p>
                            Locations
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="{{ route('admin.glocation') }}"
                                    class="nav-link {{ session('lsbsm') == 'glocation' ? ' active ' : '' }}">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>{{ __('All Locations') }}</p>
                                </a>
                            </li>


                    </ul>
                </li>


            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
