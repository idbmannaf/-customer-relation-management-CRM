<nav class="main-header navbar nav-child-indent- nav-compact-  navbar-expand navbar-primary  navbar-dark border-bottom-0 elevation-2 dropdown-legacy- nav-collapse-hide-child- " style="color: #fff">
    <!-- Left navbar links -->
    <ul class="navbar-nav ">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                    class="fas fa-bars"></i></a>
        </li>

    </ul>
@include('users.layouts.inc.headerRoleArea')
</nav>
