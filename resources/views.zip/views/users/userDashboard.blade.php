@extends('customer.layouts.customerMaster')
@section('content')
<div class="card shadow">
    <div class="card-body">
        <h1 class="text-center">Hello {{$customer->customer_name?? ''}}</h1>
    </div>
</div>
@endsection
