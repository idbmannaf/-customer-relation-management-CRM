@extends('employee.layouts.employeeMaster')
@section('content')
    <div class="card shadow">
        <div class="card-body text-center">
            @if ($employee->team_admin)
                <h1>Team Admin Of {{ $employee->company->name }}</h1>
            @else
            <h1>Team Member Of {{ $employee->company->name }}</h1>
            @endif
        </div>
    </div>

    @if ($employee->team_admin)
        <div class="row">
            <div class="col-lg-4 col-12">
                <div class="small-box bg-info">
                    <div class="inner text-center">
                        <h3>{{ $employee->company->team_members()->count() }}</h3>
                        <p>Total Members</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="{{ route('employee.myTeam') }}" class="small-box-footer">More info <i
                            class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-12">
                <div class="small-box bg-info">
                    <div class="inner text-center">
                        <h3>{{ $employee->company->name }}</h3>
                        <p>My Company</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-12">
                <div class="small-box bg-info">
                    <div class="inner text-center">
                        <h3>{{ $myCustomer }}</h3>
                        <p>My Customers</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="{{route('employee.myCustomers',$employee)}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
    @endif
@endsection
